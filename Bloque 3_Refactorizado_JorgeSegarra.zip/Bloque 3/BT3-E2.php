<!doctype html>
<html lang="es">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>

<body>

  <div class="container-fluid">
    <div class="row gray justify-content-center" id="content-row">
      <div class="col-md-3 col-sm align-self-center"> <!--Column-->
        <form name="form" method="POST">
          <!----------------------------------------------ROW------------------------------------>
          <div class="form-row" style="margin-top:40%">
            <!------------Texto------------->
            <div class="form-group col">  <!--Column-->
              <input type="text" class="form-control text-center" name="texto" id="texto" value="<?=getInputText()?>">
            </div>
          </div>
          <!---------------------------------------------/ROW------------------------------------>

          <!----------------------------------------------ROW------------------------------------>
          <div class="form-row ">
            <!------------Radios-------------->
            <div class="form-group col text-center">  <!--Column-->
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox"name="bold"<?=check('bold')?>>
                    <label class="form-check-label">Negrita</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox"name="italic"<?=check('italic')?>>
                    <label class="form-check-label">Cursiva</label>
                    </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox"name="underline"<?=check('underline')?>>
                    <label class="form-check-label">Subrayado</label>
                </div>
            </div>
          </div>
          <!---------------------------------------------/ROW------------------------------------>

          <!----------------------------------------------ROW------------------------------------>
          <div class="form-row ">
            <!------------Boton----------->
            <div class="form-group col text-center">  <!--Column-->
              <button type="submit" class="btn btn-secondary" name="submit" id="submit">Aceptar</button>
            </div>
          </div>
          <!---------------------------------------------/ROW------------------------------------>
        </form>

      </div>
    </div>
     <!----------------------------------------------ROW------------------------------------>
    <div class="row mx-auto justify-content-center">
      <div class="col-6 border border-primary rounded text-center"> <!--Column-->
        <h2 style="<?=setTextStyle()?>"><?=getInputText()?></h2>
      </div>
    </div>
    <!---------------------------------------------/ROW------------------------------------>
  </div>

  <!--************************************* PHP **************************************-->
  <?php 
    function getInputText(){
        $inputText = $_REQUEST['texto'];
        return (isset($inputText) && $inputText!="") ? $inputText : "Sample text";
    }
    function check($name){
        if(isset($_REQUEST[$name]))return "checked";
    }
    function setTextStyle(){
        $style = "";
        if (isset($_REQUEST['bold'])){$style .= "font-weight:bold;";} 
        if (isset($_REQUEST['italic'])){$style .= "font-style:italic;";} 
        if (isset($_REQUEST['underline'])){$style .= "text-decoration:underline;";}
        return $style;
    }
  ?>
  
</body>

</html>