<!doctype html>
<html lang="en">
  <head>    
        <title>Title</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
    <body>
        <div class="container-fluid">
            <div class="row gray justify-content-center" id="content-row" style="margin-top:20%">
                <div class="col-md-8 col-sm align-self-center">
                    <form name="form" method="POST" class="border border-primary rounded p-2">
                         <!----------------------------------------ROW------------------------------------>
                         <div class="form-row">
                            <!------------Dolares------------->
                            <div class="col-md-1"></div>
                            <div class="form-group col-md-4 text-center">
                                <label>Dolares</label>
                                <input type="text" class="form-control text-center" name="dollar" id="dollar" value="1.27">
                            </div>
                            <!-----------Libras----------->
                            <div class="col-md-2"></div>
                            <div class="form-group col-md-4 text-center">
                                <label>Libras</label>
                                <input type="text" class="form-control text-center" name="pound" id="pound" value="0.79">
                            </div>   
                        </div>
                        <!--------------------------------------/ROW------------------------------------>

                        <!----------------------------------------ROW------------------------------------>
                        <div class="form-row">
                            <!------------Cantidad 1------------->
                            <div class="form-group col text-center">
                                <label>Cantidad</label>
                                <input type="text" class="form-control text-center" name="amount1" id="amount1" value="1.00">
                            </div>
                            <!------------Currency 1------------>
                            <div class="form-group col text-center">
                                <label>en</label>
                                <select class="form-control" name="currency1" id="currency1">
                                    <option value="eur" <?=select("eur","currency1")?>>EUR</option>
                                    <option value="dollar" <?=select("dollar","currency1")?>>USD</option>
                                    <option value="pound" <?=select("pound","currency1")?>>GBP</option>
                                </select>
                            </div>
                            <div class="col-md-2 text-center align-self-center">
                                <span> = </span>
                            </div>
                            <!------------Cantidad 2------------->
                            <div class="form-group col text-center">
                                <label>Cantidad</label>
                                <input type="text" class="form-control text-center" name="amount2" id="amount2" value="<?=set_amount($_REQUEST['currency1'],$_REQUEST['currency2'])?>" disabled>
                            </div>
                             <!------------Currency 2------------>
                             <div class="form-group col text-center">
                                <label>en</label>
                                <select class="form-control" name="currency2" id="currency2">
                                    <option value="eur" <?=select("eur","currency2")?>>EUR</option>
                                    <option value="dollar" <?=select("dollar","currency2")?>>USD</option>
                                    <option value="pound" <?=select("pound","currency2")?>>GBP</option>
                                </select>
                            </div>
                        </div>
                        <!--------------------------------------/ROW------------------------------------>

                        <!----------------------------------------ROW------------------------------------>
                        <div class="form-row">
                            <div class="form-group col text-center">
                                <input type="image" src="index.jpeg" width ="150"/>
                            </div>
                        </div>
                        <!--------------------------------------/ROW------------------------------------>
                    </form>
                </div>
            </div>
        <div>

        <!--************************************* PHP **************************************-->
        <?php 
            function set_amount($currency1,$currency2){
                $value1 = $currency1 == 'eur' ? $_REQUEST['amount1'] : $_REQUEST['amount1']/$_REQUEST[$currency1];
                return $currency1!=$currency2 ? $value1 * $_REQUEST[$currency2] : $_REQUEST['amount1'];
            }

            function select($option,$currency){
                if(isset($_REQUEST[$currency]) && $_REQUEST[$currency] == $option )return "selected";
            }
        ?>
    </body>
</html>