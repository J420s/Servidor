<!doctype html>
<html lang="es">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  
  
</head>

<body>

  <div class="container-fluid">
    <div class="row gray justify-content-center" id="content-row">
      <div class="col-md-3 col-sm align-self-center"> <!--Column-->
        <form name="form" method="POST">
          <!----------------------------------------------ROW------------------------------------>
          <div class="form-row" style="margin-top:40%">
            <!------------Texto------------->
            <div class="form-group col">  <!--Column-->
              <input type="text" class="form-control text-center" name="texto" id="texto" value="<?=getInputText($_REQUEST['texto'])?>">
            </div>
          </div>
          <!---------------------------------------------/ROW------------------------------------>

          <!----------------------------------------------ROW------------------------------------>
          <div class="form-row ">
            <!------------Radios-------------->
            <div class="form-group col text-center">  <!--Column--> 
              <div class="form-check form-check-inline">
                <input type="radio" class="form-check-input" name="radio" id="radio" value="1" <?=check(1,$_REQUEST['radio']);?>>
                <label class="form-check-label">Izquierda</label>
              </div>
              <div class="form-check form-check-inline">
                <input type="radio" class="form-check-input" name="radio" id="radio" value="2" <?=check(2,$_REQUEST['radio']);?>>
                <label class="form-check-label">Centro</label>
              </div>
              <div class="form-check form-check-inline">
                <input type="radio" class="form-check-input" name="radio" id="radio" value="3" <?=check(3,$_REQUEST['radio']);?>>
                <label class="form-check-label">Derecha</label>
              </div>
            </div>
          </div>
          <!---------------------------------------------/ROW------------------------------------>

          <!----------------------------------------------ROW------------------------------------>
          <div class="form-row ">
            <!------------Boton----------->
            <div class="form-group col text-center">  <!--Column-->
              <button type="submit" class="btn btn-secondary" name="submit" id="submit" ">Aceptar</button>
            </div>
          </div>
          <!---------------------------------------------/ROW------------------------------------>
        </form>
      </div>
    </div>
     <!----------------------------------------------ROW------------------------------------>
    <div class="row mx-auto justify-content-center">
      <div class="col-6  <?=align( $_REQUEST['radio'])?> border border-primary rounded"> <!--Column-->
        <h2><?=getInputText($_REQUEST['texto'])?></h2>
      </div>
    </div>
    <!---------------------------------------------/ROW------------------------------------>
  </div>

  <!--************************************* PHP **************************************-->
  <?php 
    function getInputText($inputText){
      return (isset($inputText) && $inputText!="") ? $inputText : "Sample text";
    }
    function check($value,$radio){
      if(isset($radio)&& $radio==$value){return "checked";}
    }
    function align($radio){
      if (isset($radio)) switch($radio) {
        case '1':
          return "text-left";
          break;
        case '2':
          return "text-center";
          break;
        case '3':
          return "text-right";
          break;
      }
    }
  ?>
  
</body>

</html>