<!doctype html>
<html lang="es">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>

<body>

  <div class="container-fluid">
    <div class="row justify-content-center" id="content-row" >
      <div class="col-md-3 col-sm align-self-center" > <!--Column-->
        <form name="form" method="POST" enctype="multipart/form-data">
          <!----------------------------------------------ROW------------------------------------>
          <div class="form-row" style="margin-top:40%">
            <!------------Foto-------------->
            <div class="form-group col">
                <input type="hidden" name="MAX_FILE_SIZE" value="40960">
              <input type="file" class="form-control-file" accept="image/*" name="foto" id="foto">
            </div>

          </div>
          <!---------------------------------------------/ROW------------------------------------>

          <!----------------------------------------------ROW------------------------------------>
          <div class="form-row ">
            <!------------Boton----------->
            <div class="form-group col">  <!--Column-->
              <button type="submit" class="btn btn-secondary" name="submit" id="submit">Aceptar</button>
            </div>
          </div>
          <!---------------------------------------------/ROW------------------------------------>
        </form>

      </div>
    </div>
     <!----------------------------------------------ROW------------------------------------>
    <div class="row mx-auto justify-content-center">
      <div class="col-6 border border-primary rounded text-center"> <!--Column-->
        <?=uploadStatus() ? uploadStatus() : "<h2 class='text-danger'>Ningún archivo seleccionado!</h2>"?>
      </div>
    </div>
    <!---------------------------------------------/ROW------------------------------------>
  </div>

  <!--************************************* PHP **************************************-->
  <?php 

    saveFile();

    function uploadStatus(){
        if(isset($_FILES['foto']['error'])){
            $file_error = $_FILES['foto']['error'];
            $file_tmp_name = $_FILES['foto']['tmp_name'];
            $file_type = $_FILES['foto']['type'];

            if($file_type != 'image/gif') $file_error = 13;
            switch($file_error){
                case '0':
                    return "<h2 class='text-success'>Archivo subido con éxito!!</h2>";
                    break;
                case '2':
                    return "<h2 class='text-danger'>Archivo demasiado grande!</h2>";
                    exit;
                case '13':
                    return "<h2 class='text-danger'>Tipo de archivo incorrecto!</h2>";
                    exit;
                default:
                    return "<h2 class='text-danger'>Ningún archivo seleccionado!</h2>";
            }
        }      
    }

    function saveFile(){
        $file_name = pathinfo($_FILES['foto']['name'])['filename'];
        $file_ext = pathinfo($_FILES['foto']['name'])['extension'];
        $file_tmp_name = $_FILES['foto']['tmp_name'];
        if (is_uploaded_file($file_tmp_name)===true){
            $new_path = './img/'.$file_name;
            $new_path.=".".$file_ext;
            move_uploaded_file($file_tmp_name, $new_path);
        }
    }

    function myText(){
        $inputText = uploadStatus();
        return (isset($inputText) && $inputText!="") ? $inputText : "No file submitted!";
    }
  ?>
  
</body>

</html>