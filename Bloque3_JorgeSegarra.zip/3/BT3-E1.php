<!doctype html>
<html lang="en">
  <head>
        <title>Title</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
    <body>
        <div style="width:40%;position:relative;margin:0 auto;padding:10px;margin-top:100px;border-style:ridge;">
            <h2 style="<?=align()?>"><?=$_REQUEST['intext'];?></h2>
            <hr style="border-top:1px solid;">
            <form action="" method="post">
                <div class="form-group">
                    <label>Introduce el texto a mostrar: </label>
                    <input class="form-control form-control-sm" type="text" name="intext" style="width:50%;float:right;" value = "<?=$_REQUEST['intext'];?>">
                </div>
                <div style="clear:both;float:left;"><p>Alinear texto: </p></div>
                <div id="checkbox-group" style="text-align:center;">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio"name="radio"value="1"<?=check(1);?>>
                        <label class="form-check-label">Izquierda</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio"name="radio"value="2"<?=check(2);?>>
                        <label class="form-check-label">Centro</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio"name="radio"value="3"<?=check(3);?>>
                        <label class="form-check-label">Derecha</label>
                    </div>
                </div> 
                <div style="clear:both;margin-left:0;">
                    <button type="submit" class="btn btn-primary">Aceptar</button>
                    
                </div>
            </form>
        </div>

        <?php 
           function check($value){
               $radio = $_REQUEST['radio'];
               if(isset($radio)&& $radio==$value){return "checked";}
           }
           function align(){
            $radio = $_REQUEST['radio'];
            if (isset($radio)) switch($radio) {
                case '1':
                    return "text-align:left;";
                    break;
                case '2':
                    return "text-align:center;";
                    break;
                case '3':
                    return "text-align:right;";
                    break;
            }}  
        ?>
    </body>
</html>