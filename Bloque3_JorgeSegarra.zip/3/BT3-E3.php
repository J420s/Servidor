<!doctype html>
<html lang="en">
  <head>    
        <title>Title</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
    <body>
        <div style="width:500px;position:relative;margin:0 auto;padding:10px;margin-top:100px;border-style:ridge;">
            <h2 style="font-weight:bold;">Subir un archivo al servidor</h2>
            <hr style="border-top:1px solid;">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <input type="hidden" name="MAX_FILE_SIZE" value="40960">
                    <label>Buscar en:</label>
                    <input name="imagen" type="file" style="width:160px;">
                </div>
                <div>
                    <button type="submit" class="btn btn-primary">Enviar</button>
                </div>
            </form>
        </div>

        <?php 
            $file_error = $_FILES['imagen']['error'];
            $file = $_FILES['imagen']['name'];
            $path=pathinfo($file);
            $file_name = $path['filename'];
            $file_ext = $path['extension'];
            $file_tmp_name = $_FILES['imagen']['tmp_name'];
            $file_size = $_FILES['imagen']['size'];
            $file_max_size = $_POST['MAX_FILE_SIZE'];
            $file_type = $_FILES['imagen']['type'];
            if($file_type != 'image/gif')$file_error = 13;
            if(isset($file)) switch($file_error){
                case '0':
                    echo "Succes!";
                    break;
                case '2':
                    echo "Archivo demasiado grande!";
                    exit;
                case '13':
                    echo "Tipo de archivo incorrecto!";
                    exit;
            }
            if (is_uploaded_file($file_tmp_name)===true){
                $new_path = './img/'.$file_name;
                $new_path.=".".$file_ext;
                move_uploaded_file($file_tmp_name, $new_path);
            }
        ?>
    </body>
</html>