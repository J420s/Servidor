<!doctype html>
<html lang="en">
  <head>    
        <title>Title</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
    <body>
        <div style="width:700px;position:relative;margin:0 auto;padding:10px;margin-top:100px;border-style:ridge;">
            <h6><strong>Cambio de divisas tomando el euro como referencia</strong></h6>
            <hr style="border-top:1px solid;">
            <form action="" method="post">
                <div class="form-group">
                    <label style="float:left;margin-right:30px;margin-top:5px;">1 Euro</label>
                    <input class="form-control form-control-sm" type="text" name="dolares" style="float:left;width:100px;" value = "<?=isset($_POST['dolares']) ? $_POST['dolares']: "1.27"?>">
                    <label style="margin-left:15px;margin-top:5px;">Dolares</label>
                </div>
                <div class="form-group">
                    <label style="float:left;margin-right:30px;margin-top:5px;">1 Euro</label>
                    <input class="form-control form-control-sm" type="text" name="libras" style="float:left;width:100px;" value = "<?=isset($_POST['libras']) ? $_POST['libras']: "0.79"?>">
                    <label style="margin-left:15px;margin-top:5px;">Libras</label>
                </div>
                <div class="form-group">
                    <label style="float:left;margin-right:5px;margin-top:5px;">Cantidad:</label>
                    <input class="form-control form-control-sm" type="text" name="old_amount" style="float:left;width:100px;" value ="<?=isset($_POST['old_amount']) ? $_POST['old_amount']: "1.00"?>">
                    <label style="margin:5px;float:left;">en</label>
                    <select class="form-control" name="old_cur" style="width:110px;float:left;">
                        <option value="0">Euros</option>
                        <option value="1">Dolares</option>
                        <option value="2">Libras</option>
                    </select>
                    <label style="margin:5px;float:left;">=> Cantidad:</label>
                    <input class="form-control form-control-sm" type="text" name="new_amount" style="width:100px;float:left;" value = "<?=set_amount()?>" disabled="disabled">
                    <label style="margin:5px;float:left;">en</label>
                    <select class="form-control" name="new_cur" style="width:110px;">
                        <option value="0">Euros</option>
                        <option value="1">Dolares</option>
                        <option value="2">Libras</option>
                    </select>
                </div>
                <div style="margin-left:300px">
                    <button type="submit"class="btn btn-primary">Convertir</button>
                </div>
            </form>
        </div>

        <?php 
            function set_amount(){
                $dolares = $_REQUEST['dolares'];
                $libras = $_REQUEST['libras'];
                $amount = $_REQUEST['old_amount'];
                $old_cur = $_REQUEST['old_cur'];
                $new_cur = $_REQUEST['new_cur'];

                if(isset($amount)){
                    if($old_cur!=$new_cur){
                        switch($old_cur){
                            case '0':
                                $new_amount = $new_cur == '1' ? ($amount*$dolares) : ($amount*$libras);
                                break;
                            case '1':
                                $new_amount = $new_cur == '0' ? ($amount/$dolares) : (($amount*$libras)/$dolares);
                                break;
                            case '2':
                                $new_amount = $new_cur == '0' ? ($amount/$libras) : (($amount*$dolares)/$libras);
                                break;     
                        }
                    }
                    else{$new_amount=$amount;}
                    
                }
                return $new_amount;
            }
        ?>
    </body>
</html>