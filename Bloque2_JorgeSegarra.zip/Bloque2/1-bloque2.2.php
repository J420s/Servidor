<?php
    $clasificacion['Alonso']['Valencia']=1;
    $clasificacion['Hamilton']['Valencia']=4;
    $clasificacion['Massa']['Valencia']=2;
    $clasificacion['Raikonen']['Valencia']=3;
    $clasificacion['Alonso']['China']=1;
    $clasificacion['Hamilton']['China']=4;
    $clasificacion['Massa']['China']=2;
    $clasificacion['Raikonen']['China']=3;
    $clasificacion['Alonso']['Brasil']=1;
    $clasificacion['Hamilton']['Brasil']=4;
    $clasificacion['Massa']['Brasil']=2;
    $clasificacion['Raikonen']['Brasil']=3;

    $points = [0,10,8,7,6,4,3,2,1];
    $result;
    echo "<h1>Clasificación de formula 1:</h1>";

    foreach ($clasificacion as $pilot => $citys) {
       foreach ($citys as $city => $pos) {
           $result[$pilot] = $result[$pilot] + $points[$pos];
       }
    }
    foreach ($result as $pilot => $value) {
        echo"$pilot = $value <br>";
    }
?>
