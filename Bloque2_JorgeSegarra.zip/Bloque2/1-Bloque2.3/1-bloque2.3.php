<?php
	$dir = "./img";
	echo"<h1>Tabla de fotos con enlace</h1>";
	echo"<table border='2'>";
	echo "<tr>";
	$cont = 0;
	if(is_dir($dir)&&$handler = opendir($dir)){
		while (false !== ($file = readdir($handler))) {
			if($file !== ".." && $file !== "."){
				if(preg_match("/jpg$|png$|gif$|bmp$|jpeg$/", $file)){
					if($cont==4){
						echo"</tr><tr>";
						$cont = 0;
					}
					$path = "$dir/$file";
					echo'<td><a href="'.$path.'"><img src="'.$path.'" height="100" width="100"></a></td>';
					$cont++;
				}
					
			}	
		}
		closedir($handler);
	}
	echo "</tr>";
	echo"</table>";
?>
