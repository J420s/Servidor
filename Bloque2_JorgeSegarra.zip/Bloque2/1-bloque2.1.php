
<?php
    echo"<table border='2'>";
    $ejeX = 23;
    $ejeY = 1;
    for ($j=0; $j<=10; $j++) {
        echo"<tr>";
        for ($i=22; $i<=33; $i++) { 
            if($j==0 && $i==22){
                echo"<td>/</td>";
            }
            elseif($j==0){
                echo"<td>$ejeX</td>";
                $ejeX++;
            }
            elseif($i==22){
                echo"<td>$ejeY</td>";
                $ejeY++;
            }
            else{
                if($i % $j==0){
                    echo"<td style='background-color:blue;'>-</td>";
                }
                else{
                    echo"<td style='background-color:red;'>-</td>";
                }
            }
        }
        echo"</tr>";   
    }
?> 
